/** Automatically generated file. DO NOT MODIFY */
package com.example.dmstree;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}