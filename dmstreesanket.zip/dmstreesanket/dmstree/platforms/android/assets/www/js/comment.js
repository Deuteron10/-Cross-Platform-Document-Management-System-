function addcomment(){
	//alert("in comment");
	var comments=$('#comments').val();
	//alert(comment);
       var docid=localStorage.getItem("documentId");
		var docName=localStorage.getItem("documentName");
		var userid=localStorage.getItem("userid");
		var docRev=localStorage.getItem("documentRev");
		var tenantid=localStorage.getItem("usertenantid");
		var newDate=localStorage.getItem("uploadDate");
		var comment= comments;
		var tenantname=localStorage.getItem("tenantname");
		var len=localStorage.getItem("len");
		var filenm=localStorage.getItem("filename");
	  //  alert(filenm);
	    $.ajax({
                        type: "POST",
                        async: false,
                        data:{
                            docname:docName,
                            docrev:docRev,
                            comment:comment,
                            userid:userid,
                            docid:docid,
                            
                        },
                        url: "http://www.dmstree.com/dmstreeapp/dmstree/comment.php",
                        success: function(response){
                        		//alert(response);
                        		var data = $.parseJSON(response);
                        		if(data==1}
                                {
                                	alert("Comment Added Successfully");
                                }
                       
                                }});

}