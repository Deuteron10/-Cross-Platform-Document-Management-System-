 function check_doc_exists(){
     
     var tenantname        = $('.tenantname').val();
    var tenantid           = $('.tenantid').val();
    var documentname       = $('.documentname').val();
    var checkfileexistance = new Array();
    //var fcount             = 0;
    //$('#browse_file_group .row').each(function(){
        var filename =$(this).find('input').val();
        if(filename != ''){
             var lastindex = filename.lastIndexOf('\\');
            lastindex = parseInt(lastindex)+ 1;
            filename = filename.slice(lastindex);
            checkfileexistance[fcount] = filename.toLowerCase();
            fcount++;
        }
           
    });
    if(documentname == '' && fcount > 0)
        {
            $.ajax({
                                        type: "POST",
                                        data: {
                                            tenantid : tenantid,
                                            tenantname : tenantname,
                                            checkfileexistance: checkfileexistance
                                        },
                                        url: "fileexist.php",
                                        success: function(msg){
                                            if(msg == 0)
                                                {
                                                    savedocument();
                                                }
                                            else
                                                {
                                                    alertify.set({
                                                            labels : {
                                                                    ok     : "Ok"
                                                            }
                                                        });
                                                    alertify.alert(msg+" document(s) are already exists");
                                                }
                                        }
                  });
        }
    else if(documentname != '' && fcount > 0)
        {
            savedocument();
        }
    else
        {
            alertify.alert("Please select atleast one document.");
        }
     
 }
 
 
 function savedocument(){
     var documentname = $('.documentname').val();
     alertify.set({
                    labels : {
                            ok     : "Yes",
                            cancel : "No"
                    },
                    buttonReverse : true
                });
     if(documentname != ''){
        var revfilrname = $('#browse_file_group .row').find('input').val();
        var docrev = $('.revision').val();
        docrev = parseInt(docrev) + 1;
        var lastindex = revfilrname.lastIndexOf('\\');
        lastindex = parseInt(lastindex)+ 1;
        revfilrname = revfilrname.slice(lastindex);
        var file = revfilrname.split(".");
        if(file[0].toLowerCase() == documentname.toLowerCase())
        { 
             validate_uploaddocument(); 
        }
        else
        {
            alertify.confirm("The file you have selected to add as a revision of '"+documentname+"' is stored with different name. If you proceed further system will change name of document automatically as "+documentname+', '+docrev+". Do you want to proceed?",function(e){
                if(e){
                        validate_uploaddocument(); 
                    }
            });
        }
     }
     else
     {
          validate_uploaddocument(); 
     }
 }
                 var templateflag       = 0;
                 var labelindex         = 0;
                 var textnameindex      = 0;
                 var textvalindex       = 0;
                 var datenameindex      = 0;
                 var datevalindex       = 0;
                 var textareanameindex  = 0;
                 var textareavalindex   = 0;
                 var selectnameindex    = 0;
                 var selectvalindex     = 0;
                 var radionameindex     = 0;
                 var radiovalindex      = 0;
                 var checkboxnameindex  = 0;
                 var checkboxvalindex   = 0;
                 var tableindex         = 0;
                 var tableidindex       = 0;
         
                 var labelarray           = new Array();
                 var textnamearray        = new Array();
                 var textvalarray         = new Array();
                 var datenamearray        = new Array();
                 var datevalarray         = new Array();
                 var textareanamearray    = new Array();
                 var textareavalarray     = new Array();
                 var selectnamearray      = new Array();
                 var selectvalarray       = new Array();
                 var radionamearray       = new Array();
                 var radiovalarray        = new Array();
                 var checkboxnamearray    = new Array();
                 var checkboxvalarray     = new Array();
                 var tablearray           = new Array();
                 var tablenmarray         = new Array();
                 var taglistindex         = 0;
                 var taglistarray         = new Array(); 
                 var departmenid = '';
                 var tempid = '';
                 var docexpirydate = '';
                 var filepath = '';
                 var filearray  = new Array();
                 var userid = '';
                 var revision = '';
                 var filenamecheckout = '';
                 var type ='';
                 var physicallocurl = '';
                 var phyloctags = '';
                 var isPrivate = '';
 function validate_uploaddocument() //outerform
 {
    var fileflag   = 0;
    var filename = '';
    var fileindex  = 0;
    type ='new';
    var tenantname = $('.tenantname').val();
    var tenantid = $('.tenantid').val();
    revision = $('.revision').val();
    var documentname = $('.documentname').val();
    var flag = true;
    var revflag = 0;
    filenamecheckout =$('#documentid').val();
    $('#browse_file_group .row').each(function(){
        filename = $(this).find('input').val();
        var revfilename = '';
        if(documentname)
        {
            type = 'revision';
            var lastindex = filename.lastIndexOf('\\');
            lastindex = parseInt(lastindex)+ 1;
            filename = filename.slice(lastindex);
            var lastextindex = filename.lastIndexOf('.');
            lastextindex = parseInt(lastextindex)+ 1;
            fileext = filename.slice(lastextindex);
            file = filename.slice(0,lastextindex);
            if(file.toLowerCase() == documentname.toLowerCase())
            {
                flag = true;
                fileflag = 1;
            }
            else
            {
                revfilename = documentname.toLowerCase()+'.'+fileext.toLowerCase();
                flag = true;
                fileflag = 1;
                revflag = 1;
            }
        }
        if( filename != '' && flag )
        {
            fileflag = 1;
            var lastindex = filename.lastIndexOf('\\');
            lastindex = parseInt(lastindex)+ 1;
            filename = filename.slice(lastindex);
            tenantname = tenantname.replace(/ /g,"_");
            var bucket = tenantname+"_"+tenantid;
            bucket = bucket.toLowerCase();
            filepath = "https://s3.amazonaws.com/dmstree_clients/"+bucket+"/documents";
            if(revflag == 1)
            {
               filename = revfilename;
            }
            filearray[fileindex] = filename;
            fileindex++;
        }
     });
    // alert(filename);
     if(fileflag == 0)
    {
        alertify.alert("Please select atleast one document");
    }
     else
         {
             
             $('.chosen-container-multi ul li').each(function(){
                if($(this).find('span').length > 0)
                 {
                     taglistarray[taglistindex] = $(this).find('span').text();
                     taglistindex++;
                 }
             });
             var selected_templatename = $('#template').find('form').length ;
             if((selected_templatename == 0)&&(taglistarray.length == 0))
             {
                 alertify.alert("You can not save document without tag(s) and template. Select at least one option, either tag(s) or template before saving this document.");
             } 
             else
             {
                 var innerformid = $('#template').find('form').attr('id');
                 
                 
                  docexpirydate = $('.docexpirydate').val(); 
                 
                 if($('.departmentid').val() != '')
                 {
                     departmenid = $('.departmentid').val();
                 }    
                 userid = $('.userid').val();
                 
                 var documentid = $('.documentid').val();
                 isPrivate = $('#makeprivate').is(':checked');
                 if(innerformid != undefined)
                 {
                     if(valid_form())
                     {
                         tempid = $('.templateid').val();
                         templateflag = 1;
                         $('#'+innerformid+' label').each(function(){
                            var labelname = $(this).text();
                            var labelclass = $(this).attr('class');
                            var searchlabelresult = labelclass.search('requiredcls');
                            if(searchlabelresult == '-1')
                                {
                                    labelarray[labelindex] = labelname;
                                    labelindex++;
                                }
                        });
     
                        $('#'+innerformid+' input[type=text]').each(function(){
                            var textboxname = $(this).attr('name');
                            var textboxvalue = $(this).val();
                            var tblinput = $(this).attr('class');
                            var tblsearchresult = tblinput.search('tbl_td');
                            var dateinputresult = tblinput.search('.datepicker');
                            if(textboxvalue != '' && tblsearchresult == '-1' && dateinputresult == '-1')
                                {
                                    textnamearray[textnameindex] = textboxname;
                                    textvalarray[textvalindex]   = textboxvalue;
                                    textnameindex++;
                                    textvalindex++;
                                }   
                            else if(dateinputresult > 0 && textboxvalue != '')
                                {
                                    datenamearray[datenameindex] = textboxname;
                                    datevalarray[datevalindex]   = textboxvalue;
                                    datenameindex++;
                                    datevalindex++;
                                }
                        });
     
                        $('#'+innerformid+' textarea').each(function(){
                            var textarename = $(this).attr('name');
                            var textareavalue = $(this).val();
                            if(textareavalue != '')
                                {
                                    textareanamearray[textareanameindex] = textarename;
                                    textareavalarray[textareavalindex]   = textareavalue; 
                                    textareanameindex++;
                                    textareavalindex++;
                                }

                        });
     
                        $('#'+innerformid+' select').each(function(){
                            var selectname = $(this).attr('name');
                            var selectvalue = $(this).val();
                            var selectmultiattr = $(this).attr('multiple');
                            if(selectvalue != '' && selectvalue != null)
                                {
                                    selectnamearray[selectnameindex] = selectname;
                                    selectvalarray[selectvalindex]   = selectvalue;
                                    selectnameindex++;
                                    selectvalindex++;  
                                } 
                        });
     
                        $('#'+innerformid+' input[type=radio]').each(function(){
                            var radioname = $(this).attr('name');
                            var radiovalue = $(this).val();
                            if($(this).is(":checked"))
                            {
                                radionamearray[radionameindex] = radioname;
                                radiovalarray[radiovalindex]= radiovalue;
                                radionameindex++;
                                radiovalindex++;
                            }   

                        });
     
                        $('#'+innerformid+' input[type=checkbox]').each(function(){
                            var checkboxname = $(this).attr('name');
                            var checkboxvalue = $(this).val();
                            if($(this).is(":checked"))
                                {
                                    checkboxnamearray[checkboxnameindex] = checkboxname;
                                    checkboxvalarray[checkboxvalindex] = checkboxvalue;
                                    checkboxnameindex++;
                                    checkboxvalindex++;
                                }
                        });
     
                        $('#'+innerformid+' table').each(function(){
                            var tblid = $(this).attr('id');
                            tablenmarray[tableidindex] = tblid;
                            var rowindex = 0;
                            $(this).find('tbody tr').each(function(){
                                var columnindex = 0;
                                $(this).children().each(function(){
                                    if($(this).find('input[type=text]').length)
                                        {
                                        var tdval = $(this).find('input').val();
                                        if(tdval != '')
                                            {
                                                var tddetail = rowindex+'||'+columnindex+'||'+tdval+'||'+tblid;
                                                tablearray[tableindex] = tddetail;
                                                    tableindex++;
                                            }
                                            columnindex++;
                                        }
                                    else
                                        {
                                            var thval =$(this).text();
                                            var thdetail = rowindex+'||'+columnindex+'||'+thval+'||'+tblid;
                                            tablearray[tableindex] = thdetail;
                                            columnindex++;
                                            tableindex++;
                                        }
                                });
                                rowindex++;
                            });
                            tableidindex++;
                        });
                     }    
                 } 
                 
                 if($('.physicallocationimg').length > 0)
                 {
                     physicallocurl = $('.physicallocationimg').attr('src');
                 }
                 
                 if($('.revwithoutsess').length > 0)
                 {
                    phyloctags = $('.revwithoutsess').val();
                 }
                 var submitflag = 0;
                 
                 if((innerformid != undefined && taglistarray.length > 0) || (innerformid != undefined && taglistarray.length == 0))
                 {
                     if(templateflag == 1) { submitflag = 1}
                 } 
                 else if(innerformid == undefined && taglistarray.length > 0)
                 {
                     submitflag = 1;
                 }
                 if(submitflag == 1)
                 {
                    $('#uploadDocumentForm').submit(); 
                 }
                 else 
                 {
                    alertify.alert("Some fields mentioned in template are mandatory. You need to fill those fields before saving document.");
                 }
             }    
         }
 }
