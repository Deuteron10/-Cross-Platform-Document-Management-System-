function pageredirect(ch)
{
	switch(ch)
	{
	case 1:
		window.location.href="upload_document.html";
		break;
	
	case 2:
		window.location.href="upload_template.html";
		break;
		
	case 3:
		window.location.href="homePage.html";
		break;
	
	case 4:
		window.location.href="dashboard.html";
		break;
	
	case 5:
		window.location.href='http://www.dmstree.com/DMSTree/dmstree/search.php?';
		break;
	case 6:
		window.location.href="edi_prof.html";
		break;	
	case 7:
		window.location.href="about.html";
		break;	
	case 8:
		window.location.href="contact.html";
		break;
	}
}

function logout()
	{
	var r=confirm("ARE you sure");
	if(r)
	{
	window.location.href='index.html';
	}
	}

