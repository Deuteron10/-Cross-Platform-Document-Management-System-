function uname(){
	//alert("in");
						localStorage.setItem("username", "Mahnedra Kadam");
						var uname=localStorage.getItem("username");
						//alert(uname);
						document.getElementById('tpid').innerHTML=uname;
						$.ajax({
									type:"POST",
									data:
										{
											uname:data,
											tag:'dash'
										},
										
										url:'http://www.dmstree.com/dmstreeapp/dmstree/uname.php',
										
										success:function(response)
										{
											//alert(response);
											var data=$.parseJSON(response);
											alert(data);
											document.getElementById('tpid').innerHTML=data;
											
										}
						
								});
						}