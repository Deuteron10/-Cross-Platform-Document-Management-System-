function saveBouquet(){
						alert("in update bouq ");
	var tenantid=localStorage.getItem("usertenantid");
	var docid=localStorage.getItem("documentId");
	var docName=localStorage.getItem("documentName");
	var docRev=localStorage.getItem("documentRev");
	var bouquetname=localStorage.getItem("BouquetName");
	var bouquetid=localStorage.getItem("Bouquetid");
	alert(bouquetname);
	//alert(tenantid);
						$.ajax({
							type:'POST',
							data:{
								docid:docid,
								docrevision:docRev,
								bouquetname:bouquetname,
								tenantid:tenantid,
								bouquetid:bouquetid
							},
							url:'http://www.dmstree.com/dmstreeapp/dmstree/updateBouquet.php',
							success:function(response){
							alert(response);
								
							var data=$.parseJSON(response);
						    alert(data);
										
								
								
								
								
							},
							error:function(err){
								alert(err);
							}
					});
						
}