
function getPhoto()
{  
	navigator.camera.getPicture(function(uri) {            var img = document.getElementById('image'); 
	img.style.visibility = "visible";    
	img.style.display = "block"; 
	img.src = uri; 
document.getElementById('camera_status').innerHTML = "Success";        }, 
function(e) 
{            console.log("Error getting picture: " + e);  
document.getElementById('camera_status').innerHTML = "Error getting picture.";  
},

		{ quality: 50,destinationType: navigator.camera.DestinationType.FILE_URI,sourceType: source,
    mediaType: navigator.camera.MediaType.ALLMEDIA});
};











function takePicture()
{    navigator.camera.getPicture(function(uri) {            var img = document.getElementById('image'); 
img.style.visibility = "visible";    
img.style.display = "block"; 
img.src = uri; 
document.getElementById('camera_status').innerHTML = "Success";        }, 
function(e) 
{            console.log("Error getting picture: " + e);  
document.getElementById('camera_status').innerHTML = "Error getting picture.";  
},

		{ quality: 50, destinationType: navigator.camera.DestinationType.FILE_URI,cameraDirection: 1,
	  saveToPhotoAlbum: true});
};









function uploadPhoto() {
	alert("in func");
    var imageURI = document.getElementById('image').getAttribute("src");
    alert(imageURI);
    var options = new FileUploadOptions();
    options.fileKey = "file";
    options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);
    options.mimeType = "image/jpg";
    options.chunkedMode = false;
    
    var ft = new FileTransfer();
    
    ft.upload(imageURI, "http://www.dmstree.com/dmstreeapp/dmstree/picUpload.php", win, fail,options);

    
    }
    

function win(r) {
	alert("in win");
    alert("Code = " + r.responseCode);
    alert("Response = " + r.response);
    alert("Sent = " + r.bytesSent);
    alert(r.response);
}

function fail(error) {
    alert("An error has occurred: Code = " + error.code);
    alert("upload error source " + error.source);
    alert("upload error target " + error.target);
}




 

    
    
    
    
    
    
    
    
   