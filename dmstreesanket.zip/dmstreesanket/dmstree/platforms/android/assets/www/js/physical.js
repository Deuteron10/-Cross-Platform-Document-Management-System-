$(document).ready(function(){
	
						//alert("in physc");
						$.ajax({
							type:'POST',
							data:{
								
								tag:'tag'
							},
							url:'http://www.dmstree.com/dmstreeapp/dmstree/physicallocation.php',
							success:function(response){
							//	alert(response);
								
								var data=$.parseJSON(response);
						
								var str='';
								for(i=0;i<data.length;i++)
									{ 
										
										str+='<option value="'+data[i]+'">'+data[i]+'</option>';
									}
								
								
								
								$('#gallary').append(str).selectmenu('refresh');
								//$("#s_tag").click(function(key,value){
							       // $("#s_tag").append($("<option></option>").attr(str,"value").text(str));
	//						    });
								
								
								
								
								
							},
							error:function(err){
								alert(err);
							}
					});
						
					});