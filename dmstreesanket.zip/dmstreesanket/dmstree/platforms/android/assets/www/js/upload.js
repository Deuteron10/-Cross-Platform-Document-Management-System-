$(document).ready(function(){
						//alert("in func");
						$.ajax({
							type:'POST',
							data:{
								tag:'tag'
							},
							url:'http://www.dmstree.com/dmstreeapp/dmstree/tags_upload.php',
							success:function(response){
							//	alert(response);
								
								var data=$.parseJSON(response);
						
								var str='';
								for(i=0;i<data.length;i++)
									{ 
										
										str+='<option value="'+data[i]+'">'+data[i]+'</option>';
									}
								
								
								
								$('#s_tag').append(str).selectmenu('refresh');
								//$("#s_tag").click(function(key,value){
							       // $("#s_tag").append($("<option></option>").attr(str,"value").text(str));
	//						    });
								
								
								
								
								
							},
							error:function(err){
								alert(err);
							}
					});
						
					});




/*function test()
{
	var options='';// = new Array();
	var i=0;
	$('#s_tag  option:selected').each(function(){
			 if(i){
				 options += $(this).text()+"@@";
			 }
	         i++;
	     });
	localStorage.setItem("tagoption", options);
	alert(options);
	
}*/