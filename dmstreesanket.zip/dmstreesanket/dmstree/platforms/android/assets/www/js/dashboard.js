function viewPage(docid,docName,docRev,newDate,comment,len,filename)
	{
		localStorage.setItem("documentId", docid);
		localStorage.setItem("documentName", docName);
		localStorage.setItem("documentRev", docRev);
		localStorage.setItem("uploadDate", newDate);
		localStorage.setItem("comment", comment);
		localStorage.setItem("len", len);
		localStorage.setItem("filename", filename);
		window.location.href="dashboard_select.html";
		
	}

$(document).ready(function(){


	var tenantid=localStorage.getItem("usertenantid");
	
	
	
	//alert(data);
	$.ajax({
                    type: "POST",
                    data: 
                    {
                       data:tenantid,
				       tag:'dash'
                    },
				
				url:'http://www.dmstree.com/dmstreeapp/dmstree/dashboardAPP.php',
					success:function(response)
					{
						//alert(response);
						var res=response;
						//alert(res);
						localStorage.setItem("res", res);
						//alert(x);
						var data=$.parseJSON(response);
						//alert(data);
												//var comment=data.result[0].DocumentInfo.Comments[0].CommentText;
						//alert(comment);
						
						
						var str='';
						//alert(data.result.length);
						//var x = data.result[0].DocumentInfo.UploadDate.sec;
			
						//			alert(x);
						
						for(i=0;i<data.result.length;i++)
							{ var docid=data.result[i]._id.$id;
							var docName=data.result[i].DocumentName;
							var docRev=data.result[i].LatestRevision;
							var x = data.result[i].DocumentInfo.UploadDate.sec;
							//}
							//alert(comment);
							//var f= "Comments" in data.result[i].DocumentInfo;
							//alert(f);
							var comment='';
							if("Comments" in data.result[i].DocumentInfo)
								{
								//alert('in comment');
								for(j=0;j<data.result[i].DocumentInfo.Comments.length;j++){
								comment = comment+data.result[i].DocumentInfo.Comments[j].CommentText+'@@';
								var len=data.result[i].DocumentInfo.Comments.length;
								//alert(len);
								}
								}
							var filename=data.result[i].DocumentInfo.FileName;
							var filetype = data.result[i].DocumentInfo.FileName.split('.').pop();
								
								var myDate = new Date(x*1000).toLocaleString();
								var newDate = myDate.toString('dd-MM-yy');
								//var dt_to = $.datepicker.formatDate('yy-mm-dd',new Date(x*1000));
								
								str+='<div class=myGrid><div class="ui-grid-solo" onclick="viewPage(\''+docid+'\',\''+docName+'\',\''+docRev+'\',\''+newDate+'\',\''+comment+'\',\''+len+'\',\''+filename+'\')">';
								str+='   <p>   </p>';
								str+='	<img src="img/file types/'+filetype+'.png" style= "padding-right: 20px; padding-left: 10px" alt="fType" height="92" width="72">';
								str+='	<div class="label">';
								str+='	<P><span style="color:#9DD349">Name:</span><span style="color:blue">'+data.result[i].DocumentName+'</span><br>';
								//str+='	<P><span style="color:#9DD349">Revision No:</span><span style="color:black">'+data.result[i].LatestRevision+'</span><br>';
								str+='	<P><span style="color:#9DD349">Upload Date:</span><span style="color:black">'+newDate+'</span><br>';
								str+='</div>';
								str+='</div></div><hr>';
								}
						
						$('#document_details').append(str);
						
						
					}
					

	});
});




t4r