function download()
{
	var fileTransfer = new FileTransfer();
	var filenm=localStorage.getItem("filename");
	alert(filenm);
	var url="http://www.dmstree.com/dmstreeapp/dmstree/downloadApp.php?filenm="+filenm;
	alert(url)
	var uri = encodeURI(url);
	fileURL=cordova.file.externalRootDirectory +filenm;
	alert(fileURL);
	fileTransfer.download(
	    uri,
	    fileURL,
	    function(entry) {
	        alert("download complete: " + entry.toURL());
	    },
	    function(error) {
	        alert("download error source " + error.source);
	        alert("download error target " + error.target);
	        alert("upload error code" + error.code);
	    },
	    false,
	    {
	        headers: {
	            "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
	        }
	    }
	);
	
}





function downld()
{
alert("in view");
var tenantid=localStorage.getItem("usertenantid");
var tenantname=localStorage.getItem("tenantname");
var filenm=localStorage.getItem("filename");
alert(filenm);
$.ajax({
    type: "POST",
    data: 
    {
    	filenm:filenm,
    	tenantname:tenantname,
        tenantid:tenantid
    },

url:'http://www.dmstree.com/dmstreeapp/dmstree/download.php',
	success:function(response)
	{
	alert(response);
	var fileTransfer = new FileTransfer();
	var filenm=localStorage.getItem("filename");
	alert(filenm);
	var uri = encodeURI("http://www.dmstree.com/dmstreeapp/dmstree/download.php");
	fileURL=cordova.file.externalRootDirectory +filenm;
	alert(fileURL);
	fileTransfer.download(
	    uri,
	    fileURL,
	    function(entry) {
	        alert("download complete: " + entry.toURL());
	    },
	    function(error) {
	        alert("download error source " + error.source);
	        alert("download error target " + error.target);
	        alert("upload error code" + error.code);
	    },
	    false,
	    {
	        headers: {
	            "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
	        }
	    }
	);
	}

});
}
