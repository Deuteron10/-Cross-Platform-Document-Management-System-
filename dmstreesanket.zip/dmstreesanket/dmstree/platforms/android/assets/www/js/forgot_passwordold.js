function check()
{
alert("in func");	
}

function forgot_pass()
{
	//alert("in fucn")
	
      var emailid = $('#reg_email').val();
	//alert(emailid);
      if(emailid != '' && emailid != undefined)
      {
          $.ajax({
              type:'POST',
              data:{
                  emailid:emailid,
                  type:'passwordmail'
              },
              url:'http://www.dmstree.com/dmstreeapp/dmstree/password_mail.php',
              success:function(response)
              {
            	 alert(response);
                  var data = $.parseJSON(response);
                  if(data.success == 1)
                  {
                     // alert("success");
                        //location.href='forgot_password.html';
                  }
                  else if(data.error == 1)
                  {
                      alert("Invalid user name");
                  }
              }
          });
      }
      else
      {
          alert("Please enter user name");
      }
       
}


 function verify_mail(){
	 		var emailid = $('#reg_email').val();
	 		
            if(emailid != '')
            {
                $.ajax({
                    type: "POST",
                    data: {
                            emailid:emailid
                    },
                    url: 'http://www.dmstree.com/dmstreeapp/dmstree/verifytenantinfo.php',
                    success: function(msg){
                                if(msg != ''){
                                			forgot_pass();
                                }
                                   
                                
                                else{
                                       
                                         alert('Please enter registered email id.');
                                              }     
                            }
                    });
            }
 }
  
 function reset_loginform()
 {
     $('#uname').val('');
     $('#upass').val('');
     $('#loginForm').data('bootstrapValidator').resetForm();
 }