
/*(function($){
                $(document).ready(function() {
                    value = <?php echo $filesize ?>;
                    max = <?php echo $activepackspace ?>;
                    progressBar(value,max, $('#progressBar'));
                    $('#outputmeter').text(max+'GB');
                     $("a[href ='javascript:url_change(\"dashboard.php\")']").parent().attr({'class':'col-md-2 col-sm-2 col-xs-2','style':'border-top:5px solid #009347;height: 88px;background:#bec9d3;'});
                });
            }) (jQuery);*/

$(document).ready(function(){
						//alert("in");
						var tenantid=localStorage.getItem('tenantid');
						var tenantname=localStorage.getItem('tenantname');
						$.ajax({
							type:'POST',
							data:{
								
							tenantid:tenantid,
							tenantname:tenantname
							},
							url:'http://www.dmstree.com/dmstreeapp/dmstree/progress.php',
							success:function(response){
								//alert(response);
								var data=$.parseJSON(response);
								var str='';
								str+='<br>';	
								str+='<center>';
								str+='<progress max=100 value='+data+' id="progressBar"></progress>';
			                	str+='</center>';
								
								$('#progess').append(str);
								
							},
							error:function(err){
								alert(err);
							}
					});
						
				

});
		
		                    
		           
		                    
