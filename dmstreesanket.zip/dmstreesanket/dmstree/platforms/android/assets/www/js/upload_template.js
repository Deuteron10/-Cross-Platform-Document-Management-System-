function display_template(optvalue)
 {
	 alert("in func");
     var tenantname = $('.tenantname').val();
     var tenantid   = $('.tenantid').val();
     var tempActiveSecond = true;
     $('#doc_template').find('input[type=text],textarea,select').each(function(){
            var fieldValue = $(this).parent().children().val();
            if(fieldValue != ''){
                tempActiveSecond = false;
            }
        });
     if(optvalue != ''){
        // pageActive = false;
        var pathfolder = 'templates';
        if(!tempActiveSecond)
           {
               alertify.set({
                                    labels : {
                                            ok     : "Yes",
                                            cancel : "No"
                                    },
                                    buttonReverse : true
                                });
                alertify.confirm('You are about to select another template which will wipe out current template and template data. Do you want to proceed?',function(e){
                   if(e)
                   {
                        var filedata = optvalue.split('||');
                        var filename = filedata[0];
                        var tempid = filedata[1];
                        var temppath = filedata[2];
                        $('.templatename').val(filedata[3]);
                        $('.templateid').val(tempid);
                        tenantname = tenantname.replace(" ","_");
                        var newpath = temppath+'/'+filename;
                        $.ajax({
                                type: "POST",
				data:{
                                                templatename : filename,
						pathfolder:pathfolder
                                     },
				url: "tenant_template_process.php",
				success:function(response){
                                    $("#template").css("border","1px solid gainsboro");
                                    $("#template").html(response); 
                                    setTimeout(function(){
                                    $('#doc_template').removeAttr("style");
                                    //$('#template').find('link').remove();
                                    $('.droppedField').css('width','100%');
                                    $('#doc_template').find('legend').attr('style','width:100%');
                                    $('#doc_template').find('img').attr('style','width:100%');
                                    $('link[href="bootstrap/css/bootstrap.min.css"]').remove();
                                }, 10);
                                }
                        });
                        
                   }
                }); 
                 
           }
        else
            {
                var filedata = optvalue.split('||');
                var filename = filedata[0];
                var tempid = filedata[1];
                var temppath = filedata[2];
                $('.templatename').val(filedata[3]);
                $('.templateid').val(tempid);
                tenantname = tenantname.replace(" ","_");
                var newpath = temppath+'/'+filename;
                $.ajax({
                                type: "POST",
				data:{
                                                templatename : filename,
						pathfolder:pathfolder
                                     },
				url: "tenant_template_process.php",
				success:function(response){
                                    $("#template").css("border","1px solid gainsboro");
                                    $("#template").html(response);
                                    setTimeout(function(){
                                         $('#doc_template').removeAttr("style");
                                            //$('#template').find('link').remove();
                                         $('.droppedField').css('width','100%');
                                         $('#doc_template').find('legend').attr('style','width:100%');
                                         $('#doc_template').find('img').attr('style','width:100%');
                                         $('link[href="bootstrap/css/bootstrap.min.css"]').remove();
                                        }, 10);
                                }
                });
            }
     }
     else{
         //pageActive = true;
//     }
//     else{
            if(!tempActiveSecond){
               alertify.set({
                                    labels : {
                                            ok     : "Yes",
                                            cancel : "No"
                                    },
                                    buttonReverse : true
                                });
               alertify.confirm('You are about to select another template which will wipe out current template and template data. Do you want to proceed?',function(e){
               if(e)
               {
                     $("#template").css("border","none");
                     $("#template").empty();
               } 
               });
            
            }
          else  
          {
                     $("#template").css("border","none");
                     $("#template").empty();
          }
     }
 }
 
