
function getFile()
{  var source =  navigator.camera.PictureSourceType.PHOTOLIBRARY;
	navigator.camera.getPicture(function(uri) {            var img = document.getElementById('file'); 
	img.style.visibility = "visible";    
	img.style.display = "block"; 
	img.val = uri;
	document.getElementById('camera_status').innerHTML = "Success";        }, 
function(e) 
{            console.log("Error getting picture: " + e);  
document.getElementById('camera_status').innerHTML = "Error getting picture.";  
},

		{ quality: 50,destinationType: navigator.camera.DestinationType.FILE_URI,sourceType: source,
    mediaType: navigator.camera.MediaType.ALLMEDIA});
};





function uploadFile() {
	//alert("in func");
	var options='';// = new Array();
	var i=0;
	$('#s_tag  option:selected').each(function(){
			 if(i){
				 options += $(this).text()+"@@";
			 }
	         i++;
	     });
	localStorage.setItem("tagoption", options);
	//alert(options);
    var imageURI = document.getElementById('file').val;
    alert(imageURI);
    //var imageURI="content://com.android.externalstorage.documents/document/primary%3AEightQueens_0.txt";
    //alert(imageURI);
    
    var options = new FileUploadOptions();
    options.fileKey = "file";
    options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);
   // alert(options.fileName);
    options.mimeType = "text/plain";
    options.chunkedMode = false;
    
    var params = {};
    var str_option =localStorage.getItem("tagoption");
    
    //var otion_arr = str_option.split("@@");
    params.value1 = str_option;
    
    //alert(otion_arr);
    options.params = params;

    
   
    var ft = new FileTransfer();
    
    ft.upload(imageURI,encodeURI("http://www.dmstree.com/dmstreeapp/dmstree/file_upload.php"), win, fail,options);

    
    }
    

function win(r) {
	alert("the file has uploaded");
    //alert("Code = " + r.responseCode);
    //alert("Response = " + r.response);
    //alert("Sent = " + r.bytesSent);
    //alert(r.response);
}

function fail(error) {
    alert("An error has occurred:please check your network connection Code = " + error.code);
    //alert("upload error source " + error.source);
    //alert("upload error target " + error.target);
}
