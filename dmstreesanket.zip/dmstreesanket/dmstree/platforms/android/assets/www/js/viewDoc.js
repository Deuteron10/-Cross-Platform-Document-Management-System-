$(document).ready(function(){
						//alert("in ");
	var tenantid=localStorage.getItem("usertenantid");
	//alert(tenantid);
						$.ajax({
							type:'POST',
							data:{
								tenantid:tenantid
							},
							url:'http://www.dmstree.com/dmstreeapp/dmstree/Bouquet.php',
							success:function(response){
							//	alert(response);
								
								var data=$.parseJSON(response);
								
						
								var str='';
								for(i=0;i<data.length;i++)
									{ 
									
										var bouquetName=data[i].BouquetName;
										var bouquetid=data[i]._id.$id;
										localStorage.setItem("BouquetName", bouquetName);
										localStorage.setItem("Bouquetid", bouquetid);
										str+='<option value="Bouquet:">'+data[i].BouquetName+'</option>';
									}
							
								
								
								$('#Bouquet').append(str).selectmenu('refresh');
								//$("#s_tag").click(function(key,value){
							       // $("#s_tag").append($("<option></option>").attr(str,"value").text(str));
	//						    });
								
								
								
								
								
							},
							error:function(err){
								alert(err);
							}
					});
						
					});