function login()
{
	var username=$('#uname').val();
	var password=$('#upass').val();
    
     if(username =='' || password == '')
	{
		alert('Please enter username and password');
	}
	else
	{
	alert(username+"::"+password);
	$.ajax({
                    type: "POST",
                    data: 
                    {
                       username:username,
                       password:password,
				       tag:'login'
                    },
				
				url:'http://www.dmstree.com/dmstreeapp/dmstree/my_script.php',
					success:function(response)
					{
						//alert(response);
						
						//location.href='homePage.html';
						var data = $.parseJSON(response);
						if(data.success==0)
							{
							alert("Invalid UserName And Password");
							}
						//alert(data.success);
						var tenantid=data.usertenant;
						localStorage.setItem("usertenantid", tenantid);
						var tenantname=data.tenantname;
						localStorage.setItem("usertenantname", tenantname);
						//alert(tenantname);
						var usermail=data.useremail;
						localStorage.setItem("usertmailid", usermail);
						//alert(usermail);
						var userid=data.userid.$id;
						localStorage.setItem("userid", userid);
						//alert(userid);
						
						
                       if(data.success == 1)
                        {
							location.href='homePage.html';
						}
						
						
						
					}

	});
}



}
